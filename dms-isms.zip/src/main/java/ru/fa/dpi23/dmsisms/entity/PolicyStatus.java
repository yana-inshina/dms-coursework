package ru.fa.dpi23.dmsisms.entity;

public enum PolicyStatus {
    ACTIVE,
    CANCELLED,
    EXPIRED
}
