package ru.fa.dpi23.dmsisms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmsIsmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DmsIsmsApplication.class, args);
    }
}