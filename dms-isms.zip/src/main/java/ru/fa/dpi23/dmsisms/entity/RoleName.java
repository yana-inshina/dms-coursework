package ru.fa.dpi23.dmsisms.entity;

public enum RoleName {
    INDIVIDUAL,
    CORPORATE,
    MANAGER,
    ADMIN
}